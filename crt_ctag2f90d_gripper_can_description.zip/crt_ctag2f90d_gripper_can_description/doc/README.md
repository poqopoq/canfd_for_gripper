# ctag2f90d 夹爪 CAN 实时位置控制使用说明

功能包：`crt_ctag2f90d_gripper_can_description`

通过 ROS 2 话题实时控制 ctag2f90d 夹爪位置，并周期性发布夹爪实际位置反馈。
支持**左、右两只手同时运行或各自独立运行**。

## 1. 硬件与原理

```
ROS 话题 ──> can_gripper_control 节点 ──串口──> ZQWL 卡A ──CAN──> 左夹爪
                                       └─串口──> ZQWL 卡B ──CAN──> 右夹爪
```

- CAN 卡：左、右各一块 ZQWL-USBCANFD（VID 0x3562 / PID 0x0101，单通道），
  在 Linux 下是 **USB 虚拟串口设备**（CDC-ACM，/dev/ttyACM*），节点按
  《ZQWL-USBCANFD 二次开发通讯协议 V1.05》通过串口收发 CAN 报文。
- **左右区分**：两块卡外观相同，按 USB 序列号固定分配，使用
  `/dev/serial/by-id/` 路径（不受插拔顺序影响，ttyACM0/1 会变）：
  - 左：`usb-ZQWL-CANFD_ZQWL-CANFD_6A647898200A-if00`
  - 右：`usb-ZQWL-CANFD_ZQWL-CANFD_6A64725B200A-if00`
- CAN 通道配置为仲裁域 1 Mbps / 数据域 5 Mbps（常用波特率码 0x00）；
  节点发送的帧不带 CANFD/BRS 标志，总线上即为**经典 CAN 1 Mbps 扩展帧**
  （夹爪协议兼容 CAN）。
- 夹爪侧协议为《CANFD扩展帧寄存器访问协议(兼容CAN) CFEF-RAP V2.2》，
  扩展帧 ID（29bit）：`bit0~6 设备ID | bit7 读写标志 | bit8~23 寄存器地址`。

用到的寄存器（设备 ID 默认 1）：

| 寄存器 | 含义 | 说明 |
|--------|------|------|
| 0x0100 | 电机使能 | 节点启动时自动写 1（可关） |
| 0x0102/0x0103 | 目标位置 high/low | 写目标位置（用户单位 0~1000） |
| 0x0108 | 电机动作 | 写 1 触发运动 |
| 0x0418/0x0419 | 实际位置 high/low | 只读，反馈用（用户单位 0~1000） |

> 注意：docs 旧测试脚本里的 `0x00140181 + 0xA0` 混合控制协议不适用于
> 本型号夹爪（附件一中混合控制标注"暂不支持"），请勿混用。

## 2. 依赖与安装

- ROS 2 Foxy、`pyserial`（`sudo apt install python3-serial`）
- 串口权限：把当前用户加入 `dialout` 组（**需注销重新登录生效**）：

```bash
sudo usermod -aG dialout robot11
```

构建：

```bash
cd ~/dev_ws
source /opt/ros/foxy/setup.bash
colcon build --packages-select crt_ctag2f90d_gripper_can_description
source install/setup.bash
```

> 若构建报 `No module named 'catkin_pkg'`，是 conda 的 python 抢占了
> PATH，请先 `conda deactivate` 再构建。

## 3. 使用方法

双手同时运行（默认，左/右卡按 by-id 序列号路径分配）：

```bash
ros2 launch crt_ctag2f90d_gripper_can_description can_control.launch.py
```

只运行左夹爪（独立运行）：

```bash
ros2 launch crt_ctag2f90d_gripper_can_description can_control.launch.py right:=false
```

只运行右夹爪：

```bash
ros2 launch crt_ctag2f90d_gripper_can_description can_control.launch.py left:=false
```

左右接反或串口路径不同时：

```bash
ros2 launch crt_ctag2f90d_gripper_can_description can_control.launch.py \
    left_port:=/dev/ttyACM1 right_port:=/dev/ttyACM0 rviz:=false
```

控制夹爪（一个话题区分左右：`data=[side, position]`，
side：0=左，1=右，2=双臂同时；position：0=张开，1000=闭合。
双臂需要不同值时用 `data=[2, left_position, right_position]`，一条消息严格同时下发）：

```bash
# 左夹爪到 500
ros2 topic pub /gripper/position_cmd std_msgs/Int32MultiArray "data: [0, 500]"
# 右夹爪张开
ros2 topic pub /gripper/position_cmd std_msgs/Int32MultiArray "data: [1, 0]"
# 双臂同时闭合
ros2 topic pub /gripper/position_cmd std_msgs/Int32MultiArray "data: [2, 1000]"
# 双臂同时下发不同值：左到 300，右到 800
ros2 topic pub /gripper/position_cmd std_msgs/Int32MultiArray "data: [2, 300, 800]"
```

查看实际位置反馈（data[0] 为 side，0=左 1=右）：

```bash
ros2 topic echo /gripper/position
```

## 4. 话题与参数

话题（命令、反馈各一个话题，用 data[0] 的 side 字段灵活区分左右）：

| 话题 | 类型 | 方向 | 说明 |
|------|------|------|------|
| `/gripper/position_cmd` | std_msgs/Int32MultiArray | 订阅 | `[side, position]`（side：0=左 1=右 2=双臂）或 `[2, left, right]`（双臂不同值），收到立即下发 |
| `/gripper/position` | std_msgs/Int32MultiArray | 发布 | `[side, position]` 实际位置反馈，默认 20 Hz |

节点参数（均可在 launch 文件中修改）：

| 参数 | 默认值 | 说明 |
|------|--------|------|
| `enable_left` / `enable_right` | `true` | 左/右夹爪是否使能（可只开一边独立运行） |
| `left_port` / `right_port` | by-id 序列号路径 | 左/右夹爪 ZQWL 卡的串口 |
| `left_device_id` / `right_device_id` | `1` | 左/右夹爪设备 ID |
| `serial_baud` | `921600` | 串口波特率（设备硬件自动匹配） |
| `save_params` | `true` | CAN 通道参数是否写入设备 flash |
| `motor_enable_on_start` | `true` | 启动时自动给电机上使能 |
| `min_position` / `max_position` | `0` / `1000` | 命令位置限幅 |
| `cmd_topic` / `feedback_topic` | 见上 | 话题名 |
| `enable_feedback` | `true` | 是否启用位置反馈 |
| `feedback_rate` | `20.0` | 反馈频率 Hz |
| `publish_joint_states` | `true` | 是否发布 `joint_states` 驱动 rviz 模型跟随 |
| `joint_states_side` | `left` | rviz 单模型跟随哪一侧：`left`/`right`/`none` |
| `opening_min_mm` / `opening_max_mm` | `0.0` / `90.0` | 闭合（指尖相碰）/张开对应的指腹张开量（运动学标定值） |

## 5. rviz 模型跟随真实夹爪

节点会把反馈位置（0~1000，**0 = 张开，1000 = 闭合**）线性映射为指腹张开量
（90~0 mm），再经 `scripts/gripper_kinematics.py`（移植自
`crt_ctag2f90d_gripper_visualization_acc` 的运动学解析解）换算为
`Left_1_Joint` 关节角，以 10 Hz 发布到 `/joint_states`。其余 5 个关节由
URDF 的 mimic 关系自动随动，rviz 中的模型会实时跟随真实夹爪开合。

由于 rviz 中只有单个夹爪模型，双手同时运行时由 `joint_states_side`
参数选择跟随左或右（默认 `left`），设为 `none` 可关闭跟随。

对应关系：

| 反馈位置 | 张开量 | Left_1_Joint |
|----------|--------|--------------|
| 0（张开） | 90 mm | ≈ 0 rad |
| 500 | 45 mm | ≈ -0.49 rad |
| 1000（闭合，指尖相碰） | 0 mm | ≈ -0.908 rad |

## 6. 常见问题

- **打开串口失败 / Permission denied**：用户不在 `dialout` 组，或未重新登录；
  也可临时 `sudo chmod 666 /dev/ttyACM0 /dev/ttyACM1`。串口打不开时节点
  **不会退出**，只将该侧标记为不可用（另一侧不受影响）。
- **找不到 by-id 路径**：`ls /dev/serial/by-id/` 查看实际序列号，
  两块卡都插上后应有两个 `usb-ZQWL-CANFD_*` 条目；左右接反时对调
  `left_port`/`right_port` 即可。
- **命令下发了但夹爪不动**：确认位置值在 0~1000 范围内（超出会被限幅），
  并确认节点启动日志中有"电机已上使能"。
- **反馈没有数据**：`ros2 topic echo` 偶发收不到时可重启守护进程
  （`ros2 daemon stop && ros2 daemon start`）或用 `ros2 topic hz` 检查。
- **旧 libusb 开发库 `usbcanfd_libusb_x64_1.0.14_260701/` 与本方案无关**，
  该库适用于老款 VID 0x3068 的设备，可删除。
