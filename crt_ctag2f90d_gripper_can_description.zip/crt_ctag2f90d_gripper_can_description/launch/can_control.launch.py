import os

import launch
from launch import LaunchDescription
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from launch_ros.actions import Node
from launch_ros.parameter_descriptions import ParameterValue
from launch_ros.substitutions import FindPackageShare
from ament_index_python.packages import get_package_share_directory

PACKAGE = 'crt_ctag2f90d_gripper_can_description'

# 两块 ZQWL-USBCANFD 卡按 USB 序列号区分左右（by-id 路径不受插拔顺序影响）
DEFAULT_LEFT_PORT = '/dev/serial/by-id/usb-ZQWL-CANFD_ZQWL-CANFD_6A647898200A-if00'
DEFAULT_RIGHT_PORT = '/dev/serial/by-id/usb-ZQWL-CANFD_ZQWL-CANFD_6A64725B200A-if00'


def generate_launch_description():
    pkg_share = FindPackageShare(PACKAGE)

    rviz_arg = DeclareLaunchArgument(
        'rviz',
        default_value='true',
        description='Flag to enable rviz2 visualization'
    )
    # 左右手开关：可同时使能（双手），也可只开一边独立运行
    left_arg = DeclareLaunchArgument(
        'left', default_value='true',
        description='Enable left gripper')
    right_arg = DeclareLaunchArgument(
        'right', default_value='true',
        description='Enable right gripper')
    left_port_arg = DeclareLaunchArgument(
        'left_port', default_value=DEFAULT_LEFT_PORT,
        description='Serial port of the left gripper USBCANFD adapter')
    right_port_arg = DeclareLaunchArgument(
        'right_port', default_value=DEFAULT_RIGHT_PORT,
        description='Serial port of the right gripper USBCANFD adapter')
    js_side_arg = DeclareLaunchArgument(
        'joint_states_side', default_value='left',
        description='Which side the single rviz model follows: left/right/none')

    # 直接读取已生成的 URDF 文件（环境未安装 foxy 版 xacro，
    # xacro 文件与之内容一致，仅 mesh 路径不同）
    urdf_file = os.path.join(
        get_package_share_directory(PACKAGE),
        'urdf',
        'crt_ctag2f90d_gripper_description.urdf'
    )
    with open(urdf_file, 'r') as f:
        robot_description = f.read()

    robot_state_publisher_node = Node(
        package='robot_state_publisher',
        executable='robot_state_publisher',
        name='robot_state_publisher',
        output='screen',
        parameters=[{
            'robot_description': robot_description
        }]
    )

    # joint_states 由 can 控制节点根据真实反馈位置发布（含运动学换算），
    # 不再需要 joint_state_publisher 的零位占位

    # CAN 实时位置控制节点（ZQWL-USBCANFD 串口卡，经典 CAN 1 Mbps 扩展帧）
    # 订阅 gripper/position_cmd (std_msgs/Int32MultiArray, data=[side, position])，
    # side: 0=左 1=右 2=双臂；收到后立即写目标位置寄存器（0x0102/0x0103）
    # 并触发运动（0x0108）；以固定频率读取实际位置寄存器（0x0418/0x0419），
    # 发布到 gripper/position。
    can_gripper_node = Node(
        package=PACKAGE,
        executable='can_gripper_control.py',
        name='can_gripper_controller',
        output='screen',
        parameters=[{
            'enable_left': ParameterValue(
                LaunchConfiguration('left'), value_type=bool),
            'left_port': LaunchConfiguration('left_port'),
            'left_device_id': 1,
            'enable_right': ParameterValue(
                LaunchConfiguration('right'), value_type=bool),
            'right_port': LaunchConfiguration('right_port'),
            'right_device_id': 1,
            'serial_baud': 921600,
            'save_params': True,
            'motor_enable_on_start': True,
            'min_position': 0,
            'max_position': 1000,
            'cmd_topic': 'gripper/position_cmd',
            'feedback_topic': 'gripper/position',
            'enable_feedback': True,
            'feedback_rate': 20.0,
            'publish_joint_states': True,
            'joint_states_side': LaunchConfiguration('joint_states_side'),
            'opening_min_mm': 0.0,
            'opening_max_mm': 90.0,
        }]
    )

    rviz_node = Node(
        package='rviz2',
        executable='rviz2',
        name='rviz2',
        condition=launch.conditions.IfCondition(LaunchConfiguration('rviz')),
        arguments=['-d', PathJoinSubstitution([
            pkg_share,
            'rviz',
            'urdf.rviz'
        ])]
    )

    return LaunchDescription([
        rviz_arg,
        left_arg,
        right_arg,
        left_port_arg,
        right_port_arg,
        js_side_arg,
        robot_state_publisher_node,
        can_gripper_node,
        rviz_node
    ])
