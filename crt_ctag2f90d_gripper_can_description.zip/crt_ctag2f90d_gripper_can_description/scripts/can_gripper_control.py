#!/usr/bin/env python3
# -*- coding: UTF-8 -*-
"""ROS 2 节点：通过 ZQWL-USBCANFD 卡实时控制 ctag2f90d 夹爪位置，
总线上为经典 CAN（1 Mbps，扩展帧），支持左、右两只手同时运行或
各自独立运行。

订阅位置命令话题（std_msgs/Int32MultiArray），收到后立即通过 CAN 扩展帧
写对应夹爪的目标位置寄存器并触发运动；同时按固定频率读取实际位置寄存器，
发布到反馈话题（data=[side, position]）。

命令格式（position: 0=张开 ~ 1000=闭合）：
  data=[side, position]             side: 0=左 1=右 2=左右同值
  data=[2, left_pos, right_pos]     左右同时下发不同值（严格一条消息）

硬件链路：左、右各一块 ZQWL-USBCANFD（VID 0x3562 PID 0x0101，单通道，
USB 虚拟串口 CDC-ACM）。两块卡外观相同，按 USB 序列号区分左右：
  /dev/serial/by-id/usb-ZQWL-CANFD_ZQWL-CANFD_<序列号>-if00
该路径绑定 USB 设备序列号，不受插拔顺序影响（ttyACM0/1 会变）。
按《ZQWL-USBCANFD 二次开发通讯协议 V1.05》通过串口下发/解析 CAN 报文，
CAN0 通道配置为仲裁域 1M / 数据域 5M；本节点发送的帧不带 CANFD/BRS
标志，总线上即为经典 CAN 1 Mbps 扩展帧（夹爪协议兼容 CAN）。

夹爪协议：《CANFD扩展帧寄存器访问协议(兼容CAN) CFEF-RAP V2.2》
（配合《知行_伺服步进_通讯协议》）：
  扩展帧 ID（29bit）：bit0~6 设备ID | bit7 读写标志(1=写)
                     | bit8~23 寄存器地址 | bit24~28 保留(0)
  关键寄存器（设备 ID 默认 1）：
    0x0100  电机使能（1=上使能）
    0x0102  电机运动位置 high（临时区）
    0x0103  电机运动位置 low （临时区）
    0x0108  电机动作（1=触发运动）
    0x0418  实时反馈用户位置 high（只读，0~1000）
    0x0419  实时反馈用户位置 low （只读）
  写位置：ID=0x00010281，DLC=4，数据=[high 小端2B][low 小端2B]
  触发  ：ID=0x00010881，DLC=2，数据=01 00
  读反馈：ID=0x00041801，DLC=4；应答 ID 相同，数据 4 字节小端
"""

import math
import os
import sys
import threading

import rclpy
from rclpy.node import Node
from std_msgs.msg import Int32MultiArray
from sensor_msgs.msg import JointState

import serial

# 夹爪运动学模块（与本脚本同目录，来自 crt_ctag2f90d_gripper_visualization_acc）
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from gripper_kinematics import dphi_from_opening

# ---------------- ZQWL 串口协议常量 ----------------
CFG_HEADER = b'\x49\x3B'        # 配置帧帧头
CFG_TAIL = b'\x45\x2E'          # 配置帧帧尾
CFG_WRITE = 0x57
CFG_READ = 0x52
FUNC_DEV_INFO = 0x40            # 设备信息（只读）
FUNC_CAN_PARAM = 0x42           # CAN 通道参数
FUNC_SYS_CTRL = 0x44            # 系统控制（生效/复位/通道开关）

BAUD_CODE = 0x00                # 常用波特率码：仲裁域 1M + 数据域 5M

DATA_HEADER = 0x5A              # CAN 数据帧帧头
DATA_TAIL = 0xA5                # CAN 数据帧帧尾
HEARTBEAT_LEN = {0xFF: 17, 0xFE: 32}   # BYTE1 -> 心跳包总长

# 默认串口（按 USB 序列号的 by-id 路径，左右固定，不受插拔顺序影响）
DEFAULT_LEFT_PORT = '/dev/serial/by-id/usb-ZQWL-CANFD_ZQWL-CANFD_6A647898200A-if00'
DEFAULT_RIGHT_PORT = '/dev/serial/by-id/usb-ZQWL-CANFD_ZQWL-CANFD_6A64725B200A-if00'

# ---------------- 夹爪寄存器（CFEF-RAP） ----------------
REG_ENABLE = 0x0100             # 电机使能
REG_POSITION = 0x0102           # 电机运动位置（high+low，临时区）
REG_TRIGGER = 0x0108            # 电机动作触发
REG_FEEDBACK = 0x0418           # 实时反馈用户位置（high+low，只读，0~1000）

# ---------------- 命令话题中的左右手标识 ----------------
SIDE_LEFT = 0                   # 左夹爪
SIDE_RIGHT = 1                  # 右夹爪
SIDE_BOTH = 2                   # 左右同时

# rviz 跟随：用户位置 0~1000（0=张开，1000=闭合）线性映射到指腹张开量
# 90~0 mm，再经运动学解析解换算为 Left_1_Joint 关节角（其余 5 个关节
# 由 URDF 的 mimic 关系随动，无需发布）
LEFT_1_JOINT_LOWER = -0.90838   # URDF 关节下限 (rad)
LEFT_1_JOINT_UPPER = 0.0        # URDF 关节上限 (rad)


class GripperSide:
    """单侧夹爪：一块 ZQWL 卡（串口）+ 一个设备 ID"""

    def __init__(self, side_id: int, name: str, port: str, device_id: int):
        self.side_id = side_id
        self.name = name
        self.port = port
        self.device_id = device_id
        self.ser = None
        self.lock = threading.Lock()
        self.rx_buf = bytearray()

    def reg_id(self, addr: int, write: bool) -> int:
        """CFEF-RAP 扩展帧 ID：地址(16bit)<<8 | 读写标志<<7 | 设备ID"""
        return (addr << 8) | ((0x80 if write else 0x00) | self.device_id)


class CanGripperController(Node):
    def __init__(self):
        super().__init__('can_gripper_controller')

        # ---------------- 参数 ----------------
        # 左右手开关与串口：左右可同时使能，也可只使能一边独立运行
        self.declare_parameter('enable_left', True)
        self.declare_parameter('left_port', DEFAULT_LEFT_PORT)   # 左夹爪串口
        self.declare_parameter('left_device_id', 1)              # 左夹爪设备 ID
        self.declare_parameter('enable_right', True)
        self.declare_parameter('right_port', DEFAULT_RIGHT_PORT)  # 右夹爪串口
        self.declare_parameter('right_device_id', 1)             # 右夹爪设备 ID
        self.declare_parameter('serial_baud', 921600)    # 设备硬件自动匹配
        self.declare_parameter('save_params', True)      # 通道参数写入设备 flash
        self.declare_parameter('motor_enable_on_start', True)
        self.declare_parameter('min_position', 0)       # 张开（用户单位）
        self.declare_parameter('max_position', 1000)    # 闭合（用户单位，见映射寄存器 0x0506）
        self.declare_parameter('cmd_topic', 'gripper/position_cmd')
        self.declare_parameter('feedback_topic', 'gripper/position')
        self.declare_parameter('enable_feedback', True)
        self.declare_parameter('feedback_rate', 20.0)   # Hz
        # rviz 模型跟随（单个 URDF 模型只能跟随一侧，用 joint_states_side 选择）
        self.declare_parameter('publish_joint_states', True)
        self.declare_parameter('joint_states_side', 'left')  # left / right / none
        self.declare_parameter('opening_min_mm', 0.0)   # 闭合时指腹张开量（指尖相碰）
        self.declare_parameter('opening_max_mm', 90.0)  # 张开时指腹张开量

        gp = self.get_parameter
        enable_left = gp('enable_left').value
        enable_right = gp('enable_right').value
        self._serial_baud = gp('serial_baud').value
        self._save_params = gp('save_params').value
        self._motor_enable = gp('motor_enable_on_start').value
        self._min_position = gp('min_position').value
        self._max_position = gp('max_position').value
        cmd_topic = gp('cmd_topic').value
        feedback_topic = gp('feedback_topic').value
        enable_feedback = gp('enable_feedback').value
        feedback_rate = gp('feedback_rate').value
        self._publish_js = gp('publish_joint_states').value
        joint_states_side = gp('joint_states_side').value
        self._opening_min = gp('opening_min_mm').value
        self._opening_max = gp('opening_max_mm').value

        # ---------------- 打开串口并配置 CAN 通道 ----------------
        # 某侧打不开只记错误、跳过该侧，不退出节点：另一侧仍可独立运行，
        # 且 joint_states 照常发布，rviz 模型不会因缺 TF 而显示异常
        self._running = True
        self._sides = {}            # side_id -> GripperSide
        self._enabled_sides = []    # 使能的 side_id（无论串口是否打开成功）
        if enable_left:
            self._enabled_sides.append(SIDE_LEFT)
            self._add_side(SIDE_LEFT, 'left',
                           gp('left_port').value, gp('left_device_id').value)
        if enable_right:
            self._enabled_sides.append(SIDE_RIGHT)
            self._add_side(SIDE_RIGHT, 'right',
                           gp('right_port').value, gp('right_device_id').value)
        if not self._enabled_sides:
            raise RuntimeError('左右夹爪均未使能（enable_left/enable_right 全为 false）')
        if not self._sides:
            self.get_logger().error('左右夹爪的串口均未打开，节点空转，'
                                    '仅提供 rviz 模型显示')

        # 每侧一个接收线程，解析反馈应答帧
        self._rx_threads = []
        for grip in self._sides.values():
            t = threading.Thread(target=self._rx_loop, args=(grip,), daemon=True)
            t.start()
            self._rx_threads.append(t)

        # 电机上使能
        if self._motor_enable:
            for grip in self._sides.values():
                self._send(grip, grip.reg_id(REG_ENABLE, True), b'\x01\x00')
                self.get_logger().info(f'{grip.name}({grip.port}) 电机已上使能')

        # ---------------- ROS 接口 ----------------
        self._cmd_sub = self.create_subscription(
            Int32MultiArray, cmd_topic, self._cmd_callback, 10)
        self.get_logger().info(
            f'已订阅位置命令话题: {cmd_topic} (std_msgs/Int32MultiArray, '
            f'data=[side, position] 或 [2, left, right]，side: 0=左 1=右 '
            f'2=双臂，position: {self._min_position}~{self._max_position})')

        self._feedback_pub = None
        if enable_feedback:
            self._feedback_pub = self.create_publisher(
                Int32MultiArray, feedback_topic, 10)
            self._feedback_timer = self.create_timer(
                1.0 / feedback_rate, self._feedback_callback)
            self.get_logger().info(
                f'位置反馈已启用: {feedback_topic} @ {feedback_rate:.1f} Hz '
                f'(data=[side, position])')

        # rviz 跟随侧的 side_id（None 表示不跟随）；按使能标志判断，
        # 即使该侧串口暂时打不开也照常发布，保证模型显示正常。
        # joint_states 以 10 Hz 周期发布（晚启动的 rviz/robot_state_publisher
        # 也能收到），初始为张开零位，有反馈后跟随真实位置
        self._js_side = None
        if self._publish_js and joint_states_side in ('left', 'right'):
            want = SIDE_LEFT if joint_states_side == 'left' else SIDE_RIGHT
            if want in self._enabled_sides:
                self._js_side = want
                self._js_dphi = 0.0          # 当前关节角（rad），初始张开
                self._js_pub = self.create_publisher(JointState, 'joint_states', 10)
                self._js_timer = self.create_timer(0.1, self._js_timer_callback)
                self.get_logger().info(
                    f'joint_states 跟随已启用（{joint_states_side} 侧，'
                    'Left_1_Joint，mimic 关节自动随动，10 Hz）')
            else:
                self.get_logger().warn(
                    f'joint_states_side={joint_states_side} 但该侧未使能，'
                    '不发布 joint_states')

    # ---------------- 串口与通道配置 ----------------
    def _add_side(self, side_id: int, name: str, port: str, device_id: int):
        """打开一侧的串口并配置 CAN 通道；失败只记错误并跳过该侧"""
        grip = GripperSide(side_id, name, port, device_id)
        try:
            grip.ser = serial.Serial(port, self._serial_baud, timeout=0.02)
        except (serial.SerialException, OSError) as e:
            self.get_logger().error(
                f'打开串口 {port}（{name} 夹爪）失败: {e}，该侧不可用。'
                '请检查设备连接与权限（用户需在 dialout 组），'
                '或用 enable_left/enable_right 关闭对应侧')
            return

        # 读取设备信息，确认通讯正常（首次应答可能丢失，重试几次；
        # 最终无应答仅警告，不阻断）
        info = None
        for _ in range(3):
            info = self._config_frame(grip, FUNC_DEV_INFO, CFG_READ)
            if info is not None:
                break
        if info is not None:
            self.get_logger().info(
                f'{name}({port}) 设备信息: ' + ' '.join(f'{b:02X}' for b in info))
        else:
            self.get_logger().warn(f'{name}({port}) 读取设备信息无应答，请检查接线')

        # 设置 CAN0 参数：常用波特率码 0x00 = 仲裁域 1M / 数据域 5M
        self._config_frame(grip, FUNC_CAN_PARAM, CFG_WRITE,
                           bytes([0x00, 0x00, BAUD_CODE]))

        # 系统控制：生效参数 + 开启 CAN0
        self._config_frame(grip, FUNC_SYS_CTRL, CFG_WRITE,
                           bytes([0x01 if self._save_params else 0x00,
                                  0x00, 0x01, 0x00]))

        self._sides[side_id] = grip
        self.get_logger().info(
            f'{name} 夹爪: {port} 已打开，CAN0 已开启（经典 CAN 扩展帧，'
            f'仲裁域 1M，设备 ID={device_id}）')

    def _config_frame(self, grip: GripperSide, func: int, rw: int,
                      data: bytes = b'\x00' * 16):
        """发送一帧 22 字节配置帧；读命令返回应答的数据段（16 字节），否则 None"""
        data = data.ljust(16, b'\x00')[:16]
        frame = CFG_HEADER + bytes([func, rw]) + data + CFG_TAIL
        with grip.lock:
            grip.ser.reset_input_buffer()
            grip.ser.write(frame)
            grip.ser.flush()
            if rw != CFG_READ:
                return None
            # 通道已开启时缓冲区里可能混有心跳包，读取一段后按帧头扫描应答帧
            grip.ser.timeout = 0.3      # 配置帧应答较慢，临时放宽超时
            resp = grip.ser.read(64)
            grip.ser.timeout = 0.02
        idx = resp.find(CFG_HEADER)
        while idx >= 0 and idx + 22 <= len(resp):
            frame22 = resp[idx:idx + 22]
            if frame22[2] == func and frame22[-2:] == CFG_TAIL:
                return frame22[4:20]
            idx = resp.find(CFG_HEADER, idx + 1)
        return None

    def close(self):
        self._running = False
        for t in self._rx_threads:
            t.join(timeout=1.0)
        for grip in self._sides.values():
            if grip.ser is not None and grip.ser.is_open:
                grip.ser.close()

    # ---------------- 串口数据帧收发 ----------------
    def _build_data_frame(self, can_id: int, data: bytes) -> bytes:
        """按 ZQWL 协议构造一帧经典 CAN 数据帧（扩展帧、正常发送、CAN0 通道）

        不带 CANFD 标志（ID 最高字节 bit7=0）、不带 BRS，总线上即为
        经典 CAN 扩展帧，波特率取仲裁域 1 Mbps。
        """
        byte1 = len(data) & 0x7F                  # 通道号最低位 0 (CAN0)
        byte2 = 0x04                              # 扩展帧 + 数据帧（无 BRS）
        id_bytes = can_id.to_bytes(4, 'big')      # 经典 CAN：最高位不置 CANFD 标志
        return (bytes([DATA_HEADER, byte1, byte2]) + id_bytes
                + data + bytes([DATA_TAIL]))

    def _send(self, grip: GripperSide, can_id: int, data: bytes):
        """发送一帧 CAN 数据帧，失败只告警"""
        try:
            with grip.lock:
                grip.ser.write(self._build_data_frame(can_id, data))
                grip.ser.flush()
        except (serial.SerialException, OSError) as e:
            self.get_logger().warn(f'{grip.name}({grip.port}) 发送失败: {e}')

    def _rx_loop(self, grip: GripperSide):
        """接收线程：持续读串口并解析报文，反馈应答收到即发布"""
        expected_id = grip.reg_id(REG_FEEDBACK, False)
        while self._running:
            try:
                chunk = grip.ser.read(256)
            except (serial.SerialException, OSError) as e:
                if self._running:
                    self.get_logger().error(
                        f'{grip.name}({grip.port}) 串口读取失败: {e}，'
                        '该侧接收线程退出')
                break
            if chunk:
                grip.rx_buf += chunk
                self._parse_rx_buffer(grip, expected_id)

    def _parse_rx_buffer(self, grip: GripperSide, expected_id: int):
        """从接收缓冲区解析报文。

        报文格式：5A | BYTE1 | BYTE2 | 4B ID | DLC 字节数据 | A5
        BYTE1 为 0xFF/0xFE 时是心跳包（17/32 字节），直接跳过。
        """
        buf = grip.rx_buf
        while True:
            idx = buf.find(DATA_HEADER)
            if idx < 0:
                buf.clear()
                break
            del buf[:idx]
            if len(buf) < 2:
                break

            byte1 = buf[1]
            if byte1 in HEARTBEAT_LEN:            # 心跳包
                total = HEARTBEAT_LEN[byte1]
            else:
                total = 8 + (byte1 & 0x7F)        # 数据帧总长
            if len(buf) < total:
                break                             # 等下次接收

            frame = bytes(buf[:total])
            del buf[:total]
            if frame[-1] != DATA_TAIL:
                continue                          # 帧尾不对，丢弃

            if byte1 in HEARTBEAT_LEN:
                continue

            can_id = ((frame[3] & 0x7F) << 24) | (frame[4] << 16) \
                     | (frame[5] << 8) | frame[6]
            data = frame[7:-1]
            # 读反馈应答：ID 与请求相同，数据=[0x0418 小端][0x0419 小端]
            if can_id != expected_id or len(data) < 4:
                continue
            high = int.from_bytes(data[0:2], 'little')
            low = int.from_bytes(data[2:4], 'little')
            position = (high << 16) | low
            if self._feedback_pub is not None:
                msg = Int32MultiArray()
                msg.data = [grip.side_id, position]
                self._feedback_pub.publish(msg)
            if grip.side_id == self._js_side:
                self._follow_joint_state(position)

    # ---------------- 位置命令 ----------------
    def _cmd_callback(self, msg: Int32MultiArray):
        n = len(msg.data)
        if n == 2:
            side = int(msg.data[0])
            left_pos = right_pos = int(msg.data[1])
        elif n == 3 and int(msg.data[0]) == SIDE_BOTH:
            # data=[2, left_pos, right_pos]：左右同时下发不同值
            side = SIDE_BOTH
            left_pos, right_pos = int(msg.data[1]), int(msg.data[2])
        else:
            self.get_logger().warn(
                '命令格式错误：应为 [side, position] 或 [2, left, right]，'
                f'收到 {list(msg.data)}')
            return

        if side == SIDE_BOTH:
            targets = list(self._sides.values())
            if not targets:
                self.get_logger().warn('双臂命令下发失败：两侧串口均不可用')
                return
        elif side in self._sides:
            targets = [self._sides[side]]
        elif side in self._enabled_sides:
            name = '左' if side == SIDE_LEFT else '右'
            self.get_logger().warn(f'{name}夹爪的串口不可用，命令丢弃')
            return
        else:
            self.get_logger().warn(
                f'无效 side={side}（0=左 1=右 2=双臂），命令丢弃')
            return

        positions = {SIDE_LEFT: left_pos, SIDE_RIGHT: right_pos}
        for grip in targets:
            position = max(self._min_position,
                           min(self._max_position, positions[grip.side_id]))
            # 位置为 32 位：0x0102=high，0x0103=low，一次写 2 个寄存器，
            # 寄存器按地址顺序排放：先 high 后 low
            data = position.to_bytes(4, 'little', signed=False)
            payload = data[2:4] + data[0:2]
            self._send(grip, grip.reg_id(REG_POSITION, True), payload)
            self._send(grip, grip.reg_id(REG_TRIGGER, True), b'\x01\x00')

    # ---------------- 位置反馈 ----------------
    def _feedback_callback(self):
        """定时向各侧发送读反馈请求，应答由接收线程异步发布"""
        for grip in self._sides.values():
            self._send(grip, grip.reg_id(REG_FEEDBACK, False), bytes(4))

    # ---------------- rviz 模型跟随 ----------------
    def _follow_joint_state(self, position: int):
        """反馈位置(0~1000, 0=张开/1000=闭合) -> 指腹张开量(mm) -> 关节角，
        结果存入 _js_dphi，由定时器周期发布"""
        span = self._max_position - self._min_position
        ratio = (position - self._min_position) / span if span > 0 else 0.0
        ratio = max(0.0, min(1.0, ratio))
        # 位置 0 = 张开（opening_max），位置 1000 = 闭合（opening_min）
        opening_mm = self._opening_max - ratio * (self._opening_max - self._opening_min)
        dphi_deg = dphi_from_opening(opening_mm)
        if dphi_deg is None:
            return
        dphi_rad = math.radians(dphi_deg)
        self._js_dphi = max(LEFT_1_JOINT_LOWER, min(LEFT_1_JOINT_UPPER, dphi_rad))

    def _js_timer_callback(self):
        self._publish_joint_state(self._js_dphi)

    def _publish_joint_state(self, dphi_rad: float):
        msg = JointState()
        msg.header.stamp = self.get_clock().now().to_msg()
        msg.name = ['Left_1_Joint']       # 其余 5 个关节由 mimic 随动
        msg.position = [dphi_rad]
        self._js_pub.publish(msg)


def main(args=None):
    rclpy.init(args=args)
    node = None
    try:
        node = CanGripperController()
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass
    finally:
        if node is not None:
            node.close()
            node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
