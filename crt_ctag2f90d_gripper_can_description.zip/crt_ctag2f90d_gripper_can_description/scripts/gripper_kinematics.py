# -*- coding: utf-8 -*-
import math
A_b         = (-30.14132741, 104.14702225)
B_b         = (-16.000, 121.00)
C_b         = (-70.50, 141.51248153)
D_b_0       = (-56.35867259, 158.36545928)
P_slider_0  = (-15.5, 104.01346791)
P_1link_0   = (-47.75238454, 120.45194994)

C_off       = (C_b[0] - A_b[0], C_b[1] - A_b[1])
P1_off_base = (P_1link_0[0] - A_b[0], P_1link_0[1] - A_b[1])
L_3         = math.hypot(P_1link_0[0] - P_slider_0[0], P_1link_0[1] - P_slider_0[1])
L_AB        = math.hypot(B_b[0] - A_b[0], B_b[1] - A_b[1])
L_AC        = math.hypot(C_off[0], C_off[1])
L_CD        = math.hypot(D_b_0[0] - C_b[0], D_b_0[1] - C_b[1])
L_BD        = math.hypot(D_b_0[0] - B_b[0], D_b_0[1] - B_b[1])
L_P1_to_A   = math.hypot(*P1_off_base)

FINGER_PAD_OFFSET = 51.0


def _rotate_xy(p, theta_deg):
    th = math.radians(theta_deg)
    c, s = math.cos(th), math.sin(th)
    return (p[0]*c - p[1]*s, p[0]*s + p[1]*c)


def _solve_a_cos_b_sin_eq_c(a, b, c, phys_min_deg=-90.0, phys_max_deg=0.0):
    R = math.hypot(a, b)
    if abs(c / R) > 1.0:
        return None
    phi = math.atan2(b, a)
    alpha = math.acos(c / R)
    cand = [phi - alpha, phi + alpha,
            phi - alpha + 2*math.pi, phi - alpha - 2*math.pi,
            phi + alpha + 2*math.pi, phi + alpha - 2*math.pi]
    valid = []
    for ang in cand:
        if abs(a*math.cos(ang) + b*math.sin(ang) - c) > 1e-6:
            continue
        while ang > math.pi:
            ang -= 2*math.pi
        while ang <= -math.pi:
            ang += 2*math.pi
        deg = math.degrees(ang)
        if phys_min_deg <= deg <= phys_max_deg:
            valid.append(deg)
    if not valid:
        return None
    return min(valid, key=lambda x: abs(x - (phys_min_deg + phys_max_deg) / 2))

def dphi_from_d(d):
    X0 = P_slider_0[0] - A_b[0]
    Y0 = P_slider_0[1] - A_b[1]
    u, v = P1_off_base
    L_P1_sq = u*u + v*v
    a = -2*(X0*u + (Y0 - d)*v)
    b =  2*(X0*v - (Y0 - d)*u)
    c = L_3**2 - L_P1_sq - X0**2 - (Y0 - d)**2
    return _solve_a_cos_b_sin_eq_c(a, b, c, -90.0, 0.0)


def d_from_dphi(dphi_deg):
    th = math.radians(dphi_deg)
    P_1_new_x = A_b[0] + P1_off_base[0]*math.cos(th) - P1_off_base[1]*math.sin(th)
    P_1_new_y = A_b[1] + P1_off_base[0]*math.sin(th) + P1_off_base[1]*math.cos(th)
    dx = P_slider_0[0] - P_1_new_x
    val = L_3**2 - dx**2
    if val < 0:
        return None
    dy = math.sqrt(val)
    candidates = [P_slider_0[1] - P_1_new_y - dy, P_slider_0[1] - P_1_new_y + dy]
    valid = [c for c in candidates if c >= 0]
    return min(valid) if valid else None


def dphi_from_support_distance(target_support_distance):
    target_X_C = -target_support_distance / 2.0
    a = C_off[0]
    b = -C_off[1]
    c = target_X_C - A_b[0]
    return _solve_a_cos_b_sin_eq_c(a, b, c, -90.0, 0.0)


def dphi_from_opening(opening_mm):
    target_support = opening_mm + FINGER_PAD_OFFSET
    return dphi_from_support_distance(target_support)


class GripperKinematicsRight(object):
    def __init__(self):
        self.A = A_b
        self.B = B_b
        self.L_3 = L_3

    def fk_from_d(self, d):
        dphi = dphi_from_d(d)
        if dphi is None:
            return None
        new_C_off = _rotate_xy(C_off, dphi)
        new_C = (A_b[0] + new_C_off[0], A_b[1] + new_C_off[1])
        D_off_0 = (D_b_0[0] - B_b[0], D_b_0[1] - B_b[1])
        new_D_off = _rotate_xy(D_off_0, dphi)
        new_D = (B_b[0] + new_D_off[0], B_b[1] + new_D_off[1])
        W_C = 2 * abs(new_C[0])
        W_D = 2 * abs(new_D[0])
        return {
            'd': d,
            'dphi_deg': dphi,
            'new_C': new_C,
            'new_D': new_D,
            'C_C_mirror': W_C,
            'D_D_mirror': W_D,
            'finger_opening_mm': W_C - FINGER_PAD_OFFSET,
        }

    def ik_from_opening(self, opening_mm):
        target_support_distance = opening_mm + FINGER_PAD_OFFSET
        dphi = dphi_from_support_distance(target_support_distance)
        if dphi is None:
            return None
        d = d_from_dphi(dphi)
        if d is None:
            return None
        return {
            'd': d,
            'dphi_deg': dphi,
            'opening_mm': opening_mm,
        }

    def opening_to_left_1_joint_rad(self, opening_mm):
        dphi_deg = dphi_from_opening(opening_mm)
        if dphi_deg is None:
            return None
        rad = math.radians(dphi_deg)
        if rad < -0.90838:
            rad = -0.90838
        elif rad > 0.0:
            rad = 0.0
        return rad